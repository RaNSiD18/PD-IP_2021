# ForgeSdk.JsonApiRelationshipsLinksRefs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**links** | [**JsonApiRelationshipsLinksRefsLinks**](JsonApiRelationshipsLinksRefsLinks.md) |  | [optional] 


