# ForgeSdk.CreateStorage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jsonapi** | [**JsonApiVersionJsonapi**](JsonApiVersionJsonapi.md) |  | [optional] 
**data** | [**CreateStorageData**](CreateStorageData.md) |  | [optional] 


