# ForgeSdk.JobPayload

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**input** | [**JobPayloadInput**](JobPayloadInput.md) |  | [optional] 
**output** | [**JobPayloadOutput**](JobPayloadOutput.md) |  | [optional] 


