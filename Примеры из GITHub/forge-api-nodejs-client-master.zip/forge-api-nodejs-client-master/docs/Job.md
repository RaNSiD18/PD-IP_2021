# ForgeSdk.Job

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | **String** | reporting success status | 
**urn** | **String** | the urn identifier of the source file | 
**acceptedJobs** | [**JobAcceptedJobs**](JobAcceptedJobs.md) |  | [optional] 


