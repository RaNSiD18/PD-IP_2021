# ForgeSdk.FormatsFormats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**svf** | **[String]** |  | [optional] 
**thumbnail** | **[String]** |  | [optional] 
**stl** | **[String]** |  | [optional] 
**step** | **[String]** |  | [optional] 
**iges** | **[String]** |  | [optional] 
**obj** | **[String]** |  | [optional] 


