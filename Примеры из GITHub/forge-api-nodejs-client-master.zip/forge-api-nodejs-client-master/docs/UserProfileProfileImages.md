# ForgeSdk.UserProfileProfileImages

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sizeX20** | **String** |  | [optional] 
**sizeX40** | **String** |  | [optional] 
**sizeX50** | **String** |  | [optional] 
**sizeX58** | **String** |  | [optional] 
**sizeX80** | **String** |  | [optional] 
**sizeX120** | **String** |  | [optional] 
**sizeX160** | **String** |  | [optional] 
**sizeX176** | **String** |  | [optional] 
**sizeX240** | **String** |  | [optional] 
**sizeX360** | **String** |  | [optional] 


