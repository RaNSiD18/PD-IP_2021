# ForgeSdk.Hubs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jsonapi** | [**JsonApiVersionJsonapi**](JsonApiVersionJsonapi.md) |  | [optional] 
**data** | [**[Hub]**](Hub.md) |  | 


