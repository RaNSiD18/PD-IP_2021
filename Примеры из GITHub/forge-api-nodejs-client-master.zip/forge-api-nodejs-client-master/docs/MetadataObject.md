# ForgeSdk.MetadataObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**objectid** | **Integer** | Unique ID for the object | 
**name** | **String** | Name of the object | 
**objects** | [**[MetadataObject]**](MetadataObject.md) | Optional collection of “children” objects within the hierarchy | [optional] 


