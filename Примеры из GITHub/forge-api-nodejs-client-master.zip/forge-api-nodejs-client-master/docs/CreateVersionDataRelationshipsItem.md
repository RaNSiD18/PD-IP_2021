# ForgeSdk.CreateVersionDataRelationshipsItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**CreateVersionDataRelationshipsItemData**](CreateVersionDataRelationshipsItemData.md) |  | [optional] 


