# ForgeSdk.HubRelationships

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**projects** | [**JsonApiRelationshipsLinksInternal**](JsonApiRelationshipsLinksInternal.md) |  | 


