# ForgeSdk.CreateStorageDataRelationshipsTarget

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**StorageRelationshipsTargetData**](StorageRelationshipsTargetData.md) |  | [optional] 


