# ForgeSdk.ObjectFullDetailsDeltas

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**position** | **Integer** |  | [optional] 
**sha1** | **String** |  | [optional] 


