# ForgeSdk.PostObjectSigned

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**signedUrl** | **String** | URL created for downloading the object | 
**expiration** | **Integer** | Value for expiration in minutes | 


