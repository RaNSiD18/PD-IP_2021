# ForgeSdk.MetadataCollection

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**objectid** | **Integer** | Unique ID for the object | 
**name** | **String** | Name of the object | 
**properties** | **Object** | Represents the object’s “properties” | [optional] 


