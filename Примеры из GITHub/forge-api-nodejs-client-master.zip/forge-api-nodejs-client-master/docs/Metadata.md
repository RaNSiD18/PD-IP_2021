# ForgeSdk.Metadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**MetadataData**](MetadataData.md) |  | [optional] 


