# ForgeSdk.ResourceId

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


