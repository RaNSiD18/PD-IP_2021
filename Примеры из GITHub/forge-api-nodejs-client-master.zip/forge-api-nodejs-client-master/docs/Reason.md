# ForgeSdk.Reason

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reason** | **String** | reason for failure | 


