# ForgeSdk.StorageRelationships

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**target** | [**StorageRelationshipsTarget**](StorageRelationshipsTarget.md) |  | [optional] 


