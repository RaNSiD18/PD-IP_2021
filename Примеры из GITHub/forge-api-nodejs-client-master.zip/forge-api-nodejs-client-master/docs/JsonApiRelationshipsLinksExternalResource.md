# ForgeSdk.JsonApiRelationshipsLinksExternalResource

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**meta** | [**JsonApiMetaLink**](JsonApiMetaLink.md) |  | 
**data** | [**JsonApiTypeId**](JsonApiTypeId.md) |  | 


