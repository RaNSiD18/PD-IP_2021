# ForgeSdk.JsonApiVersionJsonapi

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**version** | **String** |  | 


<a name="VersionEnum"></a>
## Enum: VersionEnum


* `0` (value: `"1.0"`)




