# ForgeSdk.BadInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**jsonapi** | [**JsonApiVersionJsonapi**](JsonApiVersionJsonapi.md) |  | [optional] 
**errors** | [**[JsonApiErrorErrors]**](JsonApiErrorErrors.md) |  | 


