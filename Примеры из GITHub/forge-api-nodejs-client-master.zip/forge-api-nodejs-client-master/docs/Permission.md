# ForgeSdk.Permission

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authId** | **String** | The authentication ID | [optional] 
**access** | **String** | The authentication access type | [optional] 


