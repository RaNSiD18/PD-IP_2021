# ForgeSdk.InputStream

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


