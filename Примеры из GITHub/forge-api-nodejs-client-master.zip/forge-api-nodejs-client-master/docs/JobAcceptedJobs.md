# ForgeSdk.JobAcceptedJobs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**output** | **Object** | identical to the request body. For more information please see the request body structure above. | 


