# ForgeSdk.JsonApiLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------


