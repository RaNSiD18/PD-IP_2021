# ForgeSdk.ProjectRelationships

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hub** | [**JsonApiRelationshipsLinksInternalResource**](JsonApiRelationshipsLinksInternalResource.md) |  | 
**rootFolder** | [**JsonApiRelationshipsLinksExternalResource**](JsonApiRelationshipsLinksExternalResource.md) |  | 


