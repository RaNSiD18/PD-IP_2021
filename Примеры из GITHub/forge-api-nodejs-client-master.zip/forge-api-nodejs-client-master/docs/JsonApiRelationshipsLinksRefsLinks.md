# ForgeSdk.JsonApiRelationshipsLinksRefsLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | [**JsonApiLink**](JsonApiLink.md) |  | 
**related** | [**JsonApiLink**](JsonApiLink.md) |  | 


