# ForgeSdk.BaseAttributesExtensionObjectWithoutSchemaLink

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | 
**version** | **String** |  | 
**data** | **Object** |  | [optional] 


