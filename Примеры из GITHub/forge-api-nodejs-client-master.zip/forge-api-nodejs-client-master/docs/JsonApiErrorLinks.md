# ForgeSdk.JsonApiErrorLinks

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**about** | [**JsonApiLink**](JsonApiLink.md) |  | 


