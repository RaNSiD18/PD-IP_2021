# ForgeSdk.MetadataMetadata

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** | Name of the model view | 
**guid** | **String** | Unique identifier for the model view | 


