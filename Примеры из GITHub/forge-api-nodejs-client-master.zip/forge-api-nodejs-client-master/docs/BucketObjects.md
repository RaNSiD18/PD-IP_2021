# ForgeSdk.BucketObjects

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**items** | [**[ObjectDetails]**](ObjectDetails.md) |  | [optional] 
**next** | **String** | Next possible request | [optional] 


