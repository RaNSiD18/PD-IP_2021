# ForgeSdk.JsonApiLinksSelf

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**self** | [**JsonApiLink**](JsonApiLink.md) |  | 


