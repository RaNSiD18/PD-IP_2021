import Background from './Background.js'

export default Background
