import BaseComponent from './BaseComponent'

export default BaseComponent
