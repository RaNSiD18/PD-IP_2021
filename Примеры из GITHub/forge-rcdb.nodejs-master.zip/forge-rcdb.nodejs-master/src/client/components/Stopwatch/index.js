import Stopwatch from './Stopwatch'

export default Stopwatch
