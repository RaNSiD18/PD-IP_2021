import ResponsiveView from './ResponsiveView'

export default ResponsiveView
