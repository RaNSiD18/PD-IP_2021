import ReactLoader from './ReactLoader'
import Loader from './Loader'
import './Loader.scss'

export {
  ReactLoader,
  Loader
}
