import PointCloudMarkup from './PointCloudMarkup'

export default PointCloudMarkup
