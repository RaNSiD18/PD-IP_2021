import './Viewing.Extension.SelectionWindow.scss'
import './Viewing.Extension.SelectionWindow'

export default 'Viewing.Extension.SelectionWindow'
