import './Viewing.Extension.DataManagement.scss'
import './Viewing.Extension.DataManagement'

export default 'Viewing.Extension.DataManagement'
