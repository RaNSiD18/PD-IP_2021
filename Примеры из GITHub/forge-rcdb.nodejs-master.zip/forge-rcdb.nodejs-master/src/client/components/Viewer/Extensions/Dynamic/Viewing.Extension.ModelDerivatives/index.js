import './Viewing.Extension.ModelDerivatives.scss'
import './Viewing.Extension.ModelDerivatives'

export default 'Viewing.Extension.ModelDerivatives'
