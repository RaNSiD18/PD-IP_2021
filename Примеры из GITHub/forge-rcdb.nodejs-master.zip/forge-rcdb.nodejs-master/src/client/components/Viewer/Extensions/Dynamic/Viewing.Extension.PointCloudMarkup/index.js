import './Viewing.Extension.PointCloudMarkup'

export default 'Viewing.Extension.PointCloudMarkup'
