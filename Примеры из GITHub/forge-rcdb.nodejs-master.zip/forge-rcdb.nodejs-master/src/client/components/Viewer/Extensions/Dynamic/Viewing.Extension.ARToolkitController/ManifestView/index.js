import ManifestView from './ManifestView'
import './ManifestView.scss'

export default ManifestView
