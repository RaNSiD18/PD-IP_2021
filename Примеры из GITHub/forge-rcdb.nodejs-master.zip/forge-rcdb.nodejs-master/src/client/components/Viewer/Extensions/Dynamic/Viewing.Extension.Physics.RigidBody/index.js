import './Viewing.Extension.Physics.RigidBody'

export default 'Viewing.Extension.Physics.RigidBody'
