import './Viewing.Extension.Material.scss'
import './Viewing.Extension.Material'

export default 'Viewing.Extension.Material'
