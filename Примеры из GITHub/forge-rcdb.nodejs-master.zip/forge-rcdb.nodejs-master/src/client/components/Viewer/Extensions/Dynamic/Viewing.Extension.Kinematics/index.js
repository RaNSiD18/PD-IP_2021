import './Viewing.Extension.Kinematics'

export default 'Viewing.Extension.Kinematics'
