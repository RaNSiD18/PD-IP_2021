import './Viewing.Extension.ModelTransformer'

export default 'Viewing.Extension.ModelTransformer'
