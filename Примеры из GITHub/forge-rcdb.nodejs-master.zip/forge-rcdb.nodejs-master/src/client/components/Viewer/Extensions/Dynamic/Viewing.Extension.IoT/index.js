import './Viewing.Extension.IoT'
import './IoT.scss'

export default 'Viewing.Extension.IoT'
