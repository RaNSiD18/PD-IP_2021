import './Viewing.Extension.Physics.Core'

export default 'Viewing.Extension.Physics.Core'
