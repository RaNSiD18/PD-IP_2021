import './Viewing.Extension.CAT'
import './CAT.HotSpot.scss'

export default 'Viewing.Extension.CAT'
