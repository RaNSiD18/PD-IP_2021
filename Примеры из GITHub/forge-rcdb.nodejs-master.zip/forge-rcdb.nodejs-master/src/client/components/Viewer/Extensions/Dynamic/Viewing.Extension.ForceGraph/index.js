import './Viewing.Extension.ForceGraph'

export default 'Viewing.Extension.ForceGraph'
