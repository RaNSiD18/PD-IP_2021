import HierarchyView from './HierarchyView'
import './HierarchyView.scss'

export default HierarchyView
