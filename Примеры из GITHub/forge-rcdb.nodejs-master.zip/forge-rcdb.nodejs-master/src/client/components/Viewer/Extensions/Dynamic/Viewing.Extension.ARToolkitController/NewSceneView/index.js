import NewSceneView from './NewSceneView'
import './NewSceneView.scss'

export default NewSceneView
