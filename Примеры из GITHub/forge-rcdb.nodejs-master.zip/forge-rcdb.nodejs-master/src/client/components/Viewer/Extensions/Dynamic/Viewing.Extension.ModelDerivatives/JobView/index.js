import JobView from './JobView'
import './JobView.scss'

export default JobView
