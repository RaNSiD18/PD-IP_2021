import ParticleSystem from './ParticleSystem'
import Vector from './Vector'

export default {
  Instance: ParticleSystem,
  Vector
}
