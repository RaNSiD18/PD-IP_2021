import './Viewing.Extension.ConfigManager'

export default 'Viewing.Extension.ConfigManager'
