
import './ui/spectrum.css'
import './ui/spectrum'
import './ui/MarkupsUiUtils'
import './ui/MarkupsStyleDropdown'
import './ui/MarkupsColorPicker'
import './ui/MarkupsStyleToggleButton'
import './ui/MarkupsStyleControlFactory'
import './ui/MarkupsUi.scss'
import './ui/MarkupsPanel'
import './ui/MarkupsUi'

import './Viewing.Extension.Markup2D.scss'
import './Viewing.Extension.Markup2D'

export default 'Viewing.Extension.Markup2D'
