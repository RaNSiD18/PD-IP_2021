import IoTGraph from './IoT.Graph'

export default IoTGraph
