import TokenView from './TokenView'
import './TokenView.scss'

export default TokenView
