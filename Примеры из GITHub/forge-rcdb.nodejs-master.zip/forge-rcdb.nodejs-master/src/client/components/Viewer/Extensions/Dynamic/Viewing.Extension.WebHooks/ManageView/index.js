import ManageView from './ManageView'
import './ManageView.scss'

export default ManageView
