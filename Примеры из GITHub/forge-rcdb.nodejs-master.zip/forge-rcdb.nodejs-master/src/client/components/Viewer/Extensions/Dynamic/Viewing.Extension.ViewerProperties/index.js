import './Viewing.Extension.ViewerProperties'

export default 'Viewing.Extension.ViewerProperties'
