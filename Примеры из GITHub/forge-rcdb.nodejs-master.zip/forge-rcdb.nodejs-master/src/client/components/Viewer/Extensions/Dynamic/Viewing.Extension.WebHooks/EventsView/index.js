import EventsView from './EventsView'
import './EventsView.scss'

export default EventsView
