import './Viewing.Extension.Database.CostBreakdown'

export default 'Viewing.Extension.Database.CostBreakdown'
