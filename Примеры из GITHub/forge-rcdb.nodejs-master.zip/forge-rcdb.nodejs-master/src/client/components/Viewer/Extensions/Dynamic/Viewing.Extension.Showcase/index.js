import './Viewing.Extension.Showcase'

export default 'Viewing.Extension.Showcase'
