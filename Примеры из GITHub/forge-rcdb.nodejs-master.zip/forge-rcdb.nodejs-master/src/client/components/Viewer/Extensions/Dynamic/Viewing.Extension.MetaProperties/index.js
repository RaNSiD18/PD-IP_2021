import './Viewing.Extension.MetaProperties.scss'
import './Viewing.Extension.MetaProperties'

export default 'Viewing.Extension.MetaProperties'
