import './Viewing.Extension.Database.Table'

export default 'Viewing.Extension.Database.Table'
