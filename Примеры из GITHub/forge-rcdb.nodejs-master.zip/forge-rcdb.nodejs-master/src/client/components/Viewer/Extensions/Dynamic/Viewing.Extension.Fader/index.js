import './Viewing.Extension.Fader'
import './Fader.scss'

export default 'Viewing.Extension.Fader'
