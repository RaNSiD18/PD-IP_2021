import template from './autodesk.viewer@camera-1.0.0.template.json'

const typeId = 'autodesk.viewer:camera-1.0.0'; const name = 'autodesk.viewer@camera'

export default {
  name,
  typeId,
  template
}
