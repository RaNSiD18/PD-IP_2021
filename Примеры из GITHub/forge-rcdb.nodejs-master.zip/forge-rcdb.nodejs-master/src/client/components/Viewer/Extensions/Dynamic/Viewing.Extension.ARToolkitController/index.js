import './Viewing.Extension.ARToolkitController.scss'
import './Viewing.Extension.ARToolkitController'

export default 'Viewing.Extension.ARToolkitController'
