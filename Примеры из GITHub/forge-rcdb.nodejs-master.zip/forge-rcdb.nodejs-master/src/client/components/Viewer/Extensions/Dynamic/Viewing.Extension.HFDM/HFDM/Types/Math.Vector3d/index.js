import template from './autodesk.math@vector3d-1.0.0.template.json'
const typeId = 'autodesk.math:vector3d-1.0.0'; const name = 'autodesk.math@vector3d'
export default {
  typeId,
  name,
  template
}
