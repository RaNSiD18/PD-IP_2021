import './Viewing.Extension.Markup3D'

export default 'Viewing.Extension.Markup3D'
