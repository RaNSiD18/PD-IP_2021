import ExportsView from './ExportsView'
import './ExportsView.scss'

export default ExportsView
