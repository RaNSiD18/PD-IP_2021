import './MarqueeSelect'
export default 'Viewing.Extension.MarqueeSelect'
