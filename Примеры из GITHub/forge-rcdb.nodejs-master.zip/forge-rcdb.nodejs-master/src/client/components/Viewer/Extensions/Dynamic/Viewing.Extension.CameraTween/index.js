import './Viewing.Extension.CameraTween'

export default 'Viewing.Extension.CameraTween'
