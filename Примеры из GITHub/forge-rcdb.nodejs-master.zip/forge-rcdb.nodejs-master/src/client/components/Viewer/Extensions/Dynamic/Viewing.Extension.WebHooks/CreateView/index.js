import CreateView from './CreateView'
import './CreateView.scss'

export default CreateView
