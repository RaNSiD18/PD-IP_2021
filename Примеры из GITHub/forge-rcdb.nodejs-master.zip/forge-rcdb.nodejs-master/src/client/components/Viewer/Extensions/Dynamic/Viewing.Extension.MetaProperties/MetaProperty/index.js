import AddMetaProperty from './AddMetaProperty'
import './MetaProperty.scss'

export {
  AddMetaProperty
}
