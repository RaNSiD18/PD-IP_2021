import ReactPanel from './ReactPanel'

export default ReactPanel
