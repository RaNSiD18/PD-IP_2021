import './Viewing.Extension.VisualReport'

export default 'Viewing.Extension.VisualReport'
