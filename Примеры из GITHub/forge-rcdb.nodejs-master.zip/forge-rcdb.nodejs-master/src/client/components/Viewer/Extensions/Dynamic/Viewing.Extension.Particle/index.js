import './Viewing.Extension.Particle'

export default 'Viewing.Extension.Particle'
