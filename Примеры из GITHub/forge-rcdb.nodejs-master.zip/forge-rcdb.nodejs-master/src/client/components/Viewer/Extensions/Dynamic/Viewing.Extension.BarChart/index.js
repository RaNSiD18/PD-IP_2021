import './Viewing.Extension.BarChart'

export default 'Viewing.Extension.BarChart'
