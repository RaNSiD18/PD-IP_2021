import './Viewing.Extension.UISettings'

export default 'Viewing.Extension.UISettings'
