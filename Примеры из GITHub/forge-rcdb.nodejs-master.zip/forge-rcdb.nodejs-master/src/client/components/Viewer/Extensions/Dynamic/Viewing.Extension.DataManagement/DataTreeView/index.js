import DataTreeView from './DataTreeView'
import './DataTreeView.scss'

export default DataTreeView
