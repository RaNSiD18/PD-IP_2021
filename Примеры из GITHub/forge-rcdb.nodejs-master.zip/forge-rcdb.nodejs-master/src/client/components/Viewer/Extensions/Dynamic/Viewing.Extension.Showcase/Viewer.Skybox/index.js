import ViewerSkybox from './Viewer.Skybox'

export default ViewerSkybox
