import './Viewing.Extension.ContextMenu'

export default 'Viewing.Extension.ContextMenu'
