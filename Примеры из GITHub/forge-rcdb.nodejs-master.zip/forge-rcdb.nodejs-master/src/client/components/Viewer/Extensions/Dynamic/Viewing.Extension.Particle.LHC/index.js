import './Viewing.Extension.Particle.LHC'

export default 'Viewing.Extension.Particle.LHC'
