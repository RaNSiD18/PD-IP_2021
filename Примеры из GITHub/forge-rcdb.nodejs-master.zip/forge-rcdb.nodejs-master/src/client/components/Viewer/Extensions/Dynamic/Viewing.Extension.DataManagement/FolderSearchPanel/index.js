import FolderSearchPanel from './FolderSearchPanel'
import './FolderSearchPanel.scss'

export default FolderSearchPanel
