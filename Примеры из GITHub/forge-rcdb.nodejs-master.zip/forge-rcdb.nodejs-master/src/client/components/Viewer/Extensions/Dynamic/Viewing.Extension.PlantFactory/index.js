import './Viewing.Extension.PlantFactory'

export default 'Viewing.Extension.PlantFactory'
