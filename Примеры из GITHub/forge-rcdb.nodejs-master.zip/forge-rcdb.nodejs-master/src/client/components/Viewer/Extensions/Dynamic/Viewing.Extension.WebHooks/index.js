import './Viewing.Extension.WebHooks.scss'
import './Viewing.Extension.WebHooks'

export default 'Viewing.Extension.WebHooks'
