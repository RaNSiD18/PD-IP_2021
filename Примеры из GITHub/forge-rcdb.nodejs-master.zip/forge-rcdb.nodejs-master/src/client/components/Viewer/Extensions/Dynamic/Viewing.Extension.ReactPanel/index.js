import './Viewing.Extension.ReactPanel'

export default 'Viewing.Extension.ReactPanel'
