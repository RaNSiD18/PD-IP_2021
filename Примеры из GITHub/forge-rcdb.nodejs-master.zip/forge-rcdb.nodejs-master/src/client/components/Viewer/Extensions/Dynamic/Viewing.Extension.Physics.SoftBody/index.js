import './Viewing.Extension.Physics.SoftBody'

export default 'Viewing.Extension.Physics.SoftBody'
