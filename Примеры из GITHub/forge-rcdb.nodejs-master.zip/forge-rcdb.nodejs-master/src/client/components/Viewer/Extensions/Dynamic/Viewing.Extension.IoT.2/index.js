import './Viewing.Extension.IoT.2'

export default 'Viewing.Extension.IoT.2'
