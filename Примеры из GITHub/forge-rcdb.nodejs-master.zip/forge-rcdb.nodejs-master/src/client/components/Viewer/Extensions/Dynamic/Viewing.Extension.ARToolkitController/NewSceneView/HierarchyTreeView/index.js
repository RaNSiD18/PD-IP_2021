import HierarchyTreeView from './HierarchyTreeView'
import './HierarchyTreeView.scss'

export default HierarchyTreeView
