import DBTable from './DBTable'

export default DBTable
