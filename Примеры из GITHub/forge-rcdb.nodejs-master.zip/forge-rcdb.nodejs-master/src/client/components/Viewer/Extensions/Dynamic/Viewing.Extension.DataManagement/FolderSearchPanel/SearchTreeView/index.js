import SearchTreeView from './SearchTreeView'
import './SearchTreeView.scss'

export default SearchTreeView
