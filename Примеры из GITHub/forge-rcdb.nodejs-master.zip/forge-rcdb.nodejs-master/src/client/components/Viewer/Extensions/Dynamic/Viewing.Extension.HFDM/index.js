import './Viewing.Extension.HFDM'

export default 'Viewing.Extension.HFDM'
