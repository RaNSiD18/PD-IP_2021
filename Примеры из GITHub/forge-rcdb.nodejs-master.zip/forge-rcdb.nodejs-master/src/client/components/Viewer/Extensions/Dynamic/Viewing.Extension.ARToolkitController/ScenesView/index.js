import ScenesView from './ScenesView'
import './ScenesView.scss'

export default ScenesView
