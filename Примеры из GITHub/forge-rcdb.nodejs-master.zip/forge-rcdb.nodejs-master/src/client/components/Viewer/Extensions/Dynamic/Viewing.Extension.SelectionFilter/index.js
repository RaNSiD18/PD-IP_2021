import './Viewing.Extension.SelectionFilter.scss'
import './Viewing.Extension.SelectionFilter'

export default 'Viewing.Extension.SelectionFilter'
