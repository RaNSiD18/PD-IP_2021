import DMUploader from './DMUploader'

export default DMUploader
