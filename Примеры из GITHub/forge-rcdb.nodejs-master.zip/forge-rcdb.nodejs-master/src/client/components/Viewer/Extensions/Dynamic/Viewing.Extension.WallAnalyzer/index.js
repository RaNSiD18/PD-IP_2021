import './Viewing.Extension.WallAnalyzer'

export default 'Viewing.Extension.WallAnalyzer'
