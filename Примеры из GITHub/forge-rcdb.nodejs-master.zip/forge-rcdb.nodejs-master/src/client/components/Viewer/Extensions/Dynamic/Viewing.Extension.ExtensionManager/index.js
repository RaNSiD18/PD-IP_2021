import './Viewing.Extension.ExtensionManager'

export default 'Viewing.Extension.ExtensionManager'
