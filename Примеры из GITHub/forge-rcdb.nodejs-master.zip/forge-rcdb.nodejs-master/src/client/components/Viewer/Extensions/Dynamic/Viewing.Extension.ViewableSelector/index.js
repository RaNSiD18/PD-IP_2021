import './Viewing.Extension.ViewableSelector'

export default 'Viewing.Extension.ViewableSelector'
