import './Viewing.Extension.ShaderMaterial'
import './Viewing.Extension.ShaderMaterial.scss'

export default 'Viewing.Extension.ShaderMaterial'
