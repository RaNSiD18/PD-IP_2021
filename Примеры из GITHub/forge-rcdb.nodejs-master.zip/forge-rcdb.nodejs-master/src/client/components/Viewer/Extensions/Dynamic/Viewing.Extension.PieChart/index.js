import './Viewing.Extension.PieChart'

export default 'Viewing.Extension.PieChart'
