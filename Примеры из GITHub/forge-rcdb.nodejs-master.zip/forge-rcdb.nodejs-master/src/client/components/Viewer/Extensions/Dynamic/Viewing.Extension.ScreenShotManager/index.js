import './Viewing.Extension.ScreenShotManager'

export default 'Viewing.Extension.ScreenShotManager'
