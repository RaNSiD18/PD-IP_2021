import PieLegend from './PieLegend'

export default PieLegend
