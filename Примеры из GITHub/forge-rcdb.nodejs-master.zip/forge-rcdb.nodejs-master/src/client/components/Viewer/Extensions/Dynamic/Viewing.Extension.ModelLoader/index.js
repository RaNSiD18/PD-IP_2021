import './Viewing.Extension.ModelLoader'

export default 'Viewing.Extension.ModelLoader'
