import './Viewing.Extension.BoundingBox'

export default 'Viewing.Extension.BoundingBox'
