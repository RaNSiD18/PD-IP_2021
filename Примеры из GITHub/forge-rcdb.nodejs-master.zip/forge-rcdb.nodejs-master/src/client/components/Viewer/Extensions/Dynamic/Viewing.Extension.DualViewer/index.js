import './Viewing.Extension.DualViewer'

export default 'Viewing.Extension.DualViewer'
