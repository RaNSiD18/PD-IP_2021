import Switch from './Switch'
import './Switch.scss'

export default Switch
