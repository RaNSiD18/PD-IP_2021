import EventsEmitter, { EventsEmitterComposer } from './EventsEmitter'

EventsEmitter.Composer = EventsEmitterComposer

export default EventsEmitter
