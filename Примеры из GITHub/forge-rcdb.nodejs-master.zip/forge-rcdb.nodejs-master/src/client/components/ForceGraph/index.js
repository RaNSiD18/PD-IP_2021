import ForceGraph from './ForceGraph'

export default ForceGraph
