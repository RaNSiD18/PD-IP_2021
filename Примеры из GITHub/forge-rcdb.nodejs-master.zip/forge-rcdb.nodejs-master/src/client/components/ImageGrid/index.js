import ImageGrid from './ImageGrid'

export default ImageGrid
