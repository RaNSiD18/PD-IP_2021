import BarChart from './BarChart'

export default BarChart
