import Label from './Label'

export default Label
