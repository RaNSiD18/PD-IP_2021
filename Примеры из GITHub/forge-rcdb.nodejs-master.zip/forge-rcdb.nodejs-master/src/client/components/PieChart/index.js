import PieChart from './PieChart'

export default PieChart
