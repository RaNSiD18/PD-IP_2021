import PaneElement from './PaneElement'
import PaneManager from './PaneManager'

export default PaneManager
