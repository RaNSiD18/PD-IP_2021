import Gradient from './Gradient'

export default Gradient
