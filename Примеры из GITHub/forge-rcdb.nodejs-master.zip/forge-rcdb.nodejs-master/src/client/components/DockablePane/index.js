import DockablePane from './DockablePane'
import './DockablePane.scss'

export default DockablePane
