import ScriptLoader from './ScriptLoader'

export default ScriptLoader
