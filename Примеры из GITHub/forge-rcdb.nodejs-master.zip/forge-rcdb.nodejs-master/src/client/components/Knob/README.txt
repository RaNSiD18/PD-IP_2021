A Pen created at CodePen.io. You can find this one at http://codepen.io/ademilter/pen/Dwelk.

 Pure CSS3, no image, no js, no woman, no cry :p —design by Piotr Kwiatkowski http://drbl.in/eXBR