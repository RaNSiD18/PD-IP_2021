import ModelUploader from './ModelUploader'

export default ModelUploader
