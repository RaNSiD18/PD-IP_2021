import ReactPie from './ReactPie'

export default ReactPie
