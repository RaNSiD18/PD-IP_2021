import RecentModels from './RecentModels'

export default RecentModels
