import LayoutDlg from './LayoutDlg'

export default LayoutDlg
