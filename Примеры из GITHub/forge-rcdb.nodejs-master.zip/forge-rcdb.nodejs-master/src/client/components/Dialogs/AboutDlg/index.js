import AboutDlg from './AboutDlg'

export default AboutDlg
