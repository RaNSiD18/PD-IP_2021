import DatabaseDlg from './DatabaseDlg'

export default DatabaseDlg
