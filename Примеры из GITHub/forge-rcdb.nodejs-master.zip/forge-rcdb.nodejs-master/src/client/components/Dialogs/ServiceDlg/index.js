import ServiceDlg from './ServiceDlg'

export default ServiceDlg
