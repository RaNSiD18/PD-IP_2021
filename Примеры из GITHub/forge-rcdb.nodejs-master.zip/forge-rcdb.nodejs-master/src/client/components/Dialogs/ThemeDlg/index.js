import ThemeDlg from './ThemeDlg'

export default ThemeDlg
