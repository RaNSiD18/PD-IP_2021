import JSONView from './JSONView'

export default JSONView
