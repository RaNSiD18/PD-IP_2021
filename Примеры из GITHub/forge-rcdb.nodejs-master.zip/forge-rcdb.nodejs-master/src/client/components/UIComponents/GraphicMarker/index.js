import GraphicMarker from './GraphicMarker'

export default GraphicMarker
