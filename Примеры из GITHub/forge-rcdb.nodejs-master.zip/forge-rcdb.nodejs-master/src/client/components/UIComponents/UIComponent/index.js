import UIComponent from './UIComponent'

export default UIComponent
