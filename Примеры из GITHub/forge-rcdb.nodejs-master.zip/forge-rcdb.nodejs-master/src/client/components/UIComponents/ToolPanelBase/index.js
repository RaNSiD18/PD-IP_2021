import ToolPanelBase from './ToolPanelBase'

export default ToolPanelBase
