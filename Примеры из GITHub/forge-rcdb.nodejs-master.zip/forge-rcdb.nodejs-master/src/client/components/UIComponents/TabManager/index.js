import TabManager from './TabManager'

export default TabManager
